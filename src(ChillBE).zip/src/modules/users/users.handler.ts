import { Request, Response } from "express";
import bcrypt from "bcrypt";
import { IUserResponse } from "../../shared/models/response.model";
import { findAll, findByUuid, insert, update, deleteUser } from "./users.service";
import { AppError } from "../../shared/helper/appError";
import { IUserBody, IUserParams } from "./users.model";

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const getAllUsers = async (
  req: Request,
  res: Response<IUserResponse>,
) => {
  const users = await findAll();

  if (users.length < 1) {
    throw new AppError("NOT_DATA", "No Data Found", 404);
  }

  res.status(200).json({
    success: true,
    message: "Users Retrieved Successfully.",
    results: users,
  });
};

export const getUserByUuid = async (
  req: Request<IUserParams>,
  res: Response<IUserResponse>,
) => {
  const { uuid } = req.params;
  const user = await findByUuid(uuid);

  if (!user) {
    throw new AppError("NOT_DATA", "No Data Found", 404);
  }

  res.status(200).json({
    success: true,
    message: "User Retrieved Successfully.",
    results: user,
  });
};

export const insertUser = async (
  req: Request<{}, {}, IUserBody>,
  res: Response<IUserResponse>,
) => {
  const { password } = req.body;
  if (!req.body.username || !req.body.email || !password) {
    const missingFields: string[] = [];
    if (!req.body.username) missingFields.push("username");
    if (!req.body.email) missingFields.push("email");
    if (!req.body.password) missingFields.push("password");

    throw new AppError(
      "MISSING_FIELD",
      `${missingFields.join(", ")} cannot be empty`,
      400,
    );
  }

  const isValidEmail = emailRegex.test(req.body.email);

  if (!isValidEmail) {
    throw new AppError("INVALID_EMAIL", "Invalid email format", 400);
  }

  const salt = await bcrypt.genSalt();
  const hashed = await bcrypt.hash(password, salt);
  req.body.password = hashed;

  const user = await insert(req.body);

  res.status(201).json({
    success: true,
    message: "User Created Successfully.",
    results: user,
  });
};

export const updateUser = async (
  req: Request<{ uuid: string }, {}, Partial<IUserBody>>,
  res: Response<IUserResponse>,
): Promise<Response> => {
  const { uuid } = req.params;
  if (!uuid || uuid === ":uuid") {
    throw new AppError("NO_ID", "UUID must be provided", 400);
  }

  const allowedFields: (keyof IUserBody)[] = [
    "username",
    "email",
    "password",
    "role",
    "image",
    "is_active",
  ];
  const data: Partial<IUserBody> = {};
  for (const field of allowedFields) {
    const value = req.body[field];
    if (value !== undefined) {
      Object.assign(data, { [field]: value });
    }
  }

  if (!Object.keys(data).length) {
    throw new AppError("MISSING_FIELD", "No supported fields to update", 400);
  }

  if (data.password) {
    const salt = await bcrypt.genSalt();
    const hashed = await bcrypt.hash(data.password, salt);
    data.password = hashed;
  }

  const user = await update(uuid, data);
  if (user.length < 1) {
    throw new AppError("NOT_FOUND", "Users not found", 404);
  }
  return res.json({
    success: true,
    message: "User updated successfully",
    results: user,
  });
};

export const deleteUsers = async (
  req: Request<{uuid: string}>,
  res: Response<IUserResponse>
):Promise<Response> => {
  const {uuid} = req.params
  if (!uuid || uuid === ":uuid") {
    throw new AppError("NO_ID", "UUID must be provided", 400);
  }

  const deletedUser = await deleteUser(uuid)

  return res.json({
    success: true,
    message: "User deleted successfully"
  });
}