import { AppError } from "../../shared/helper/appError";
import { IUser, IUserBody } from "./users.model";
import * as usersRepository from "./users.repository";

export const findAll = async () => {
  const users = await usersRepository.findAll();

  return users;
};

export const findByUuid = async (uuid: string) => {
  const users = await usersRepository.findByUuid(uuid);

  return users;
};

export const insert = async (data: IUserBody) => {
  const users = await usersRepository.insert(data);

  return users;
};

export const update = async (uuid: string, data: Partial<IUserBody>) => {
  const users = await usersRepository.update(uuid, data);

  return users;
};

export const deleteUser = async (uuid: string) => {
  const affectedRows = await usersRepository.deleteUser(uuid);

  if (affectedRows === 0) {
    throw new AppError("NOT_FOUND", "User not found", 404);
  }
};
